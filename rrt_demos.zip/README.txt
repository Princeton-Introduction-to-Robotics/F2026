Expert demonstrations for the flow-matching behavior cloning lab.

1500 random obstacle fields, up to 3 RRT demonstrations each (4479 demos,
188425 time steps). Expert: RRT (Lab 2) on obstacles inflated by the drone radius
(0.1 m) + a margin (0.15 m), greedy shortcutting, resampled every 0.1 m.
For each environment RRT is run 6 times; paths longer than 1.25 x the shortest are dropped.
Each path is flown under a random wind disturbance; at every step the expert action is the chunk of the
next 8 path waypoints (0.1 m apart) relative to the drone's position.
Range finder: 24 beams over 360 deg, max range 2.0 m, noise std 0.05 m,
dropout probability 0.05.

rrt_demos.npz arrays:
  obstacles   (E, 10, 3)  [cx, cy, r] per obstacle, padded with zeros; use n_obstacles
  n_obstacles (E,)
  starts, goals (E, 2)
  demo_env    (D,)  environment index of each demo
  demo_start  (D,)  index of the demo's first time step in positions / ranges
  demo_len    (D,)  number of time steps in the demo
  positions   (T, 2) drone position at each time step (all demos concatenated)
  ranges      (T, 24) noisy range finder reading recorded at each time step
  actions     (T, 8, 2) expert action chunk at each time step (waypoints relative to position)

Generated with: python generate_demos.py --envs 1500 --runs 3 --seed 0 --horizon 8
